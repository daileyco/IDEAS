### R code from vignette source 'seasonality.rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: seasonality.rnw:56-69
###################################################
seasonal.sir.model <- function (t, x, params) {  #function to return time-dependent rates
  with(
       as.list(c(x,params)),
       {
         beta <- beta0*(1+beta1*cos(2*pi*t))     #first determine time-dependent beta
         dS <- mu*(1-S)-beta*S*I                 #the system of rate equations
         dI <- beta*S*I-(mu+gamma)*I
         dR <- gamma*I-mu*R
         dx <- c(dS,dI,dR)                       #store result
         list(dx)                                #and return as a list
       }
       )
}


###################################################
### code chunk number 2: seasonality.rnw:74-85
###################################################
require(deSolve)
times <- seq(0,100,by=1/120)                     #times at which to obtain solution
params <- c(mu=1/50,beta0=1000,beta1=0.4,gamma=365/13)   #parameters
xstart <- c(S=0.06,I=0.001,R=0.939)              #initial conditions
out <- as.data.frame(lsoda(xstart,times,seasonal.sir.model,params,rtol=1e-12,hmax=1/120)) #solve
op <- par(fig=c(0,0.5,0,1),mar=c(4,4,1,1))       #set graphical parameters
plot(I~time,data=out,type='l',log='y',subset=time>=90) #plot
par(fig=c(0.5,1,0,1),mar=c(4,1,1,1),new=T)       #reset graphical parameters
plot(I~S,data=out,type='p',log='xy',subset=time>=50,yaxt='n',xlab='S',cex=0.5) #plot
text(0.02,1e-02,cex=0.7, "last 50 yr of simulation")  #annotate graph
par(op)                                          #reset graphical parameters


###################################################
### code chunk number 3: seasonality.rnw:106-123
###################################################
seasonal.age.model<-function(t,x,parms){
 S<-x[1:4]
 E<-x[5:8]
 I<-x[9:12]
 dx<-vector(length=12)
 beta<-parms$beta
 beta[2,2]<-parms$beta[2,2]*(1+0.04*cos(2*pi*t/365))
 #at all times update transmission matrix with cosine function
 day<-floor(t)  #let day e integerized time
 for(a in 1:4){
   tmp <- (beta[a,]%*%I)*S[a]
   dx[a] <- parms$nu[a]*55/75 - tmp - parms$mu[a]*S[a]
   dx[a+4] <- tmp - parms$sigma*E[a] - parms$mu[a]*E[a]
   dx[a+8] <- parms$sigma*E[a] - parms$gamma*I[a] - parms$mu[a]*I[a]    
 }  
return(list(dx))  
}


###################################################
### code chunk number 4: seasonality.rnw:128-174
###################################################
  y0<-c(0.05, 0.01, 0.01, 0.008, 0.0001, 0.0001, 0.0001, 0.0001, 0.0001, 0.0001, 0.0001, 0.0001)
parms<-list(beta=matrix(c(2.089, 2.089, 2.086, 2.037, 2.089, 9.336, 2.086, 2.037, 2.086, 2.086,
            2.086, 2.037, 2.037, 2.037, 2.037,2.037),nrow=4,byrow=TRUE),
            sigma=1/8, gamma=1/5, nu=c(1/(55*365),0,0,0),  mu=c(1/(55*365),0,0,0))
n=c(6,4,10,55)/75   #number of years in each age class
maxTime <- 100*365  #number of days in 100 years
T0=0
S=c()
E=c()
I=c()
T=c()
while(T0<maxTime){
  y=lsoda(y0,seq(T0, T0+365,by=5),seasonal.age.model,parms)
  T=rbind(T, y[2,1])
  S=rbind(S, y[2,2:5])
  E=rbind(E, y[2,6:9])
  I=rbind(I, y[2,10:13])
  y0[1]=tail(y,1)[2]-tail(y,1)[2]/6
  y0[2]=tail(y,1)[3]+tail(y,1)[2]/6 - tail(y,1)[3]/4
  y0[3]=tail(y,1)[4]+tail(y,1)[3]/4 - tail(y,1)[4]/10
  y0[4]=tail(y,1)[5]+tail(y,1)[4]/10
  y0[5]=tail(y,1)[6]-tail(y,1)[6]/6
  y0[6]=tail(y,1)[7]+tail(y,1)[6]/6 - tail(y,1)[7]/4
  y0[7]=tail(y,1)[8]+tail(y,1)[7]/4 - tail(y,1)[8]/10
  y0[8]=tail(y,1)[9]+tail(y,1)[8]/10
  y0[9]=tail(y,1)[10]-tail(y,1)[10]/6
  y0[10]=tail(y,1)[11]+tail(y,1)[10]/6 - tail(y,1)[11]/4;
  y0[11]=tail(y,1)[12]+tail(y,1)[11]/4 - tail(y,1)[12]/10;
  y0[12]=tail(y,1)[13]+tail(y,1)[12]/10
  T0=tail(T,1)
}
 
par(mfrow=c(2,1))
plot(tail(T,730),tail(S[,1],730),type='l',ylim=c(0,0.06),
     xlab='Time (days)',ylab='Proportion susceptible')
lines(tail(T,730),tail(S[,2],730),col='blue')
lines(tail(T,730),tail(S[,3],730),col='red')
lines(tail(T,730),tail(S[,4],730),col='green')
legend(x='topright',legend=c('<5','6-9','10-19','20+'),
       col=c('black','blue','red','green'),lty=1,bty='n')
plot(tail(T,730),tail(I[,1],730),type='l',log='y',ylim=c(2e-6,6e-5),
     xlab='Time (days)',ylab='Proportion infected')
lines(tail(T,730),tail(I[,2],730),col='blue')
lines(tail(T,730),tail(I[,3],730),col='red')
lines(tail(T,730),tail(I[,4],730),col='green')



