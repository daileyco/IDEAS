### R code from vignette source 'likelihood.rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: set-opts
###################################################
  glop <- options(keep.source=TRUE,width=60,continue=" ",prompt=" ")
  pdf.options(useDingbats=FALSE)
  set.seed(5384959)


###################################################
### code chunk number 2: binom-prob-plot (eval = FALSE)
###################################################
## p <- 0.3
## n <- 50
## k <- seq(0,50,by=1)
## prob <- dbinom(x=k,size=n,prob=p) 
## plot(k,prob,type='h',lwd=5,lend=1,
##      ylab="probability")


###################################################
### code chunk number 3: likelihood.rnw:124-127
###################################################
op <- par(mar=c(3,3,1,1),fig=c(0,1,0,1),mgp=c(2,1,0))
p <- 0.3
n <- 50
k <- seq(0,50,by=1)
prob <- dbinom(x=k,size=n,prob=p) 
plot(k,prob,type='h',lwd=5,lend=1,
     ylab="probability")
par(op)


###################################################
### code chunk number 4: binom-lik-plot1 (eval = FALSE)
###################################################
## k1 <- 18
## n1 <- 50
## p <- seq(0,1,by=0.001)
## plot(p,dbinom(x=k1,size=n1,prob=p,log=TRUE),
##      ylim=c(-10,-2),ylab="log-likelihood",
##      type='l')
## abline(h=dbinom(x=k1,size=n1,prob=k1/n1,log=TRUE)-
##        0.5*qchisq(p=0.95,df=1),col='red')
## abline(v=k1/n1,col='blue')


###################################################
### code chunk number 5: binom-lik-plot2 (eval = FALSE)
###################################################
## k2 <- 243
## n2 <- 782
## p <- seq(0,1,by=0.001)
## plot(p,dbinom(x=k2,size=n2,prob=p,log=TRUE),
##      ylim=c(-10,-2),ylab="log-likelihood",
##      type='l')
## abline(h=dbinom(x=k2,size=n2,prob=k2/n2,log=TRUE)-
##        0.5*qchisq(p=0.95,df=1),col='red')
## abline(v=k2/n2,col='blue')


###################################################
### code chunk number 6: likelihood.rnw:167-171
###################################################
op <- par(mar=c(3,3,1,1),fig=c(0,1,0,1),mgp=c(2,1,0),mfcol=c(1,2))
k1 <- 18
n1 <- 50
p <- seq(0,1,by=0.001)
plot(p,dbinom(x=k1,size=n1,prob=p,log=TRUE),
     ylim=c(-10,-2),ylab="log-likelihood",
     type='l')
abline(h=dbinom(x=k1,size=n1,prob=k1/n1,log=TRUE)-
       0.5*qchisq(p=0.95,df=1),col='red')
abline(v=k1/n1,col='blue')
k2 <- 243
n2 <- 782
p <- seq(0,1,by=0.001)
plot(p,dbinom(x=k2,size=n2,prob=p,log=TRUE),
     ylim=c(-10,-2),ylab="log-likelihood",
     type='l')
abline(h=dbinom(x=k2,size=n2,prob=k2/n2,log=TRUE)-
       0.5*qchisq(p=0.95,df=1),col='red')
abline(v=k2/n2,col='blue')
par(op)


###################################################
### code chunk number 7: binom-lik2
###################################################
n <- c(13,484,3200)
k <- c(4,217,1118)
dbinom(x=k,size=n,prob=0.2,log=TRUE)
sum(dbinom(x=k,size=n,prob=0.2,log=TRUE))
ll.fn <- function (p) {
  sum(dbinom(x=k,size=n,prob=p,log=TRUE))
}
p <- seq(0,1,by=0.001)
loglik <- sapply(p,ll.fn)


###################################################
### code chunk number 8: likelihood.rnw:204-205 (eval = FALSE)
###################################################
## plot(p,loglik,type='l',ylim=max(loglik)+c(-10,1))


###################################################
### code chunk number 9: closed-sir-model-defn
###################################################
require(deSolve)
sir.model.closed <- function (t, x, params) {    #here we begin a function with three arguments
  S <- x[1]                               #create local variable S, the first element of x
  I <- x[2]                               #create local variable I
  R <- x[3]                               #create local variable R
  with(                                   #we can simplify code using "with"
       as.list(params),                   #this argument to "with" lets us use the variable names
       {                                  #the system of rate equations
         dS <- -beta*S*I
         dI <- beta*S*I-gamma*I
         dR <- gamma*I
         dx <- c(dS,dI,dR)                #combine results into a single vector dx
         list(dx)                         #return result as a list
       }
       )
}                        


###################################################
### code chunk number 10: closed-sir-predictions
###################################################
prediction <- function (params, times) {
  xstart <- params[c("S.0","I.0", "R.0")]
  out <- ode(
             func=sir.model.closed,
             y=xstart,
             times=c(0,times),
             parms=params
             )
  out[-1,3]     # return the I variable only
}


###################################################
### code chunk number 11: closed-sir-negloglik
###################################################
loglik <- function (params, data) {
  times <- data$biweek/26
  pred <- prediction(params,times)
  sum(dnorm(x=data$measles,mean=pred,sd=params["sigma"],log=TRUE))
}


###################################################
### code chunk number 12: loglik-calc1 (eval = FALSE)
###################################################
## load('data.RData')
## dat <- data.frame(biweek=seq(1:dim(niamey)[1]), measles=niamey[,1])
## #niamey <- read.csv(file="niamey_measles.csv")
## #dat <- subset(niamey,community=="A")
## 
## params <- c(S.0=10000,I.0=10,gamma=365/13,beta=NA,sigma=1)
## 
## f <- function (beta) {
##   par <- params
##   par["beta"] <- beta
##   loglik(par,dat)
## }
## 
## beta <- seq(from=0,to=0.02,by=0.0001)
## ll <- sapply(beta,f)
## plot(beta,-ll,type='l',ylab="-log(L)")
## beta.hat <- beta[which.max(ll)]
## abline(v=beta.hat,lty=2)


###################################################
### code chunk number 13: loglik-plot1
###################################################
op <- par(mfcol=c(1,1),mar=c(3,3,1,1),mgp=c(2,1,0))
load('data.RData')
dat <- data.frame(biweek=seq(1:dim(niamey)[1]), measles=niamey[,1])
#niamey <- read.csv(file="niamey_measles.csv")
#dat <- subset(niamey,community=="A")

params <- c(S.0=10000,I.0=10,gamma=365/13,beta=NA,sigma=1)

f <- function (beta) {
  par <- params
  par["beta"] <- beta
  loglik(par,dat)
}

beta <- seq(from=0,to=0.02,by=0.0001)
ll <- sapply(beta,f)
plot(beta,-ll,type='l',ylab="-log(L)")
beta.hat <- beta[which.max(ll)]
abline(v=beta.hat,lty=2)
par(op)


###################################################
### code chunk number 14: poisson-lik
###################################################
poisson.loglik <- function (params, data) {
  times <- data$biweek/26
  pred <- prediction(params,times)
  sum(dpois(x=data$measles,lambda=params["p"]*pred[-1],log=TRUE))
}


###################################################
### code chunk number 15: fit-b
###################################################
require(bbmle)

#niamey <- read.csv(file="niamey_measles.csv")
#dat <- subset(niamey,community=="A")

params <- c(S.0=20000,I.0=1, R.0=0, gamma=365/13,b=NA,p=0.2)

## objective function
f <- function (log.beta) {
  par <- params
  par[c("beta")] <- exp(log.beta)
  -poisson.loglik(par,dat)
}

guess <- list(log.beta=log(220/50000))

fit0 <- mle2(f,start=guess); fit0
fit <-  mle2(f,start=as.list(coef(fit0))); fit


###################################################
### code chunk number 16: profile1
###################################################
prof.beta <- profile(fit)
plot(prof.beta, col.conf='darkblue')


###################################################
### code chunk number 17: fit-b-p
###################################################
#niamey <- read.csv(file="niamey_measles.csv")
#dat <- subset(niamey,community=="A")

params <- c(S.0=20000,I.0=1, R.0=0, gamma=365/13,b=NA,p=NA)

logit <- function (p) log(p/(1-p))      # the logit transform
ilogit <- function (x) 1/(1+exp(-x))    # inverse logit

f <- function (log.beta, logit.p) {
  par <- params
  par[c("beta","p")] <- c(exp(log.beta),ilogit(logit.p))
  -poisson.loglik(par,dat)
}

guess <- list(log.beta=log(0.005),logit.p=logit(0.2))
fit0 <- mle2(f,start=guess); fit0
fit <-  mle2(f,start=as.list(coef(fit0))); fit


###################################################
### code chunk number 18: profile2
###################################################
prof2 <- profile(fit)
plot(prof2, col.conf='darkblue')


###################################################
### code chunk number 19: confint2
###################################################
confint(prof2)
ci <- confint(prof2)
ci[1,] <- exp(ci[1,])
ci[2,] <- ilogit(ci[2,])
rownames(ci) <- c("b","p")
ci


###################################################
### code chunk number 20: predictions
###################################################
params["beta"] <- exp(coef(fit)["log.beta"])
params["p"] <- ilogit(coef(fit)["logit.p"])

times <- c(dat$biweek/26)
model.pred <- prediction(params,times)
plot(measles~times,data=dat,type='b',col='red')
lines(times,params["p"]*model.pred,type='l')


###################################################
### code chunk number 21: contour2
###################################################
#niamey <- read.csv(file="niamey_measles.csv")
#dat <- subset(niamey,community=="A")

## this time the objective function has to 
## take a vector argument
f <- function (pars) {
  par <- params
  par[c("beta","p")] <- as.numeric(pars)
  -poisson.loglik(par,dat)
}

beta <- seq(from=0.001,to=0.005,by=0.0001)
p <- seq(0,1,by=0.05)
grid <- expand.grid(beta=beta,p=p)
grid$loglik <- apply(grid,1,f)
grid <- subset(grid,is.finite(loglik))
require(lattice)
contourplot(loglik~beta+p,data=grid,cuts=20)


###################################################
### code chunk number 22: restore-opts
###################################################
options(glop)


