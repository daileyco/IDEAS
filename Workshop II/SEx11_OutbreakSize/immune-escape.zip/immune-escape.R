### R code from vignette source 'immune-escape.rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: immune-escape.rnw:59-67
###################################################
load('equine.RData')     #load the data and plot
summarize.p<-aggregate(equine$p,list(equine$a),FUN=mean)
summarize.q<-aggregate(equine$q[!is.na(equine$q)],list(equine$a[!is.na(equine$q)]),FUN=mean)
summarize.d<-aggregate(equine$d[!is.na(equine$d)],list(equine$a[!is.na(equine$d)]),FUN=mean)
par(mfrow=c(1,3))
plot(summarize.p, xlab='Amino acid differences', ylab='Fraction infected')
plot(summarize.q, xlab='Amino acid differences', ylab='Fraction infectious')
plot(summarize.d, xlab='Amino acid differences', ylab='Duration infected')


